#ifndef __AUTOCONF_COMMON_H__
#define __AUTOCONF_COMMON_H__

#endif