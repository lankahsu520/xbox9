﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/json-protocol/JsonProtocolRequest.h>

namespace Aws {
namespace JsonProtocol {}  // namespace JsonProtocol
}  // namespace Aws
