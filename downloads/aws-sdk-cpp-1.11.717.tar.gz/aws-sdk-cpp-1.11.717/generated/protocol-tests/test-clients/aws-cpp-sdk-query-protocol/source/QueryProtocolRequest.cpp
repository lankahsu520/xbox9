﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/query-protocol/QueryProtocolRequest.h>

namespace Aws {
namespace QueryProtocol {}  // namespace QueryProtocol
}  // namespace Aws
