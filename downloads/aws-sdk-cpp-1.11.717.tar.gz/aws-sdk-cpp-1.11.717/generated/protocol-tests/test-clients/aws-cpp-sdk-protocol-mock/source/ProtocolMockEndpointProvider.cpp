﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/protocol-mock/ProtocolMockEndpointProvider.h>

namespace Aws {
namespace ProtocolMock {
namespace Endpoint {}  // namespace Endpoint
}  // namespace ProtocolMock
}  // namespace Aws
